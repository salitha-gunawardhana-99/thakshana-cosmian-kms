"""

Note: This test case was not written from scratch, as it closely resembles the test case for symmetric keys.

"""

import unittest

class TestCkmsECKeysRevoke(unittest.TestCase):
    pass

if __name__ == '__main__':
    unittest.main()