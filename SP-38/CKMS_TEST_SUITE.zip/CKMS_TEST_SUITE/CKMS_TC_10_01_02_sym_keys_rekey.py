"""

10.1.2 ckms sym keys re-key

Refresh an existing symmetric key

Usage

ckms sym keys re-key [options]

Arguments

--key-id [-k] <KEY_ID> The tag to associate with the key. To specify multiple tags, use the option multiple times

"""

import unittest

class TestCkmsSymKeysRekey(unittest.TestCase):
    pass

if __name__ == '__main__':
    unittest.main()
